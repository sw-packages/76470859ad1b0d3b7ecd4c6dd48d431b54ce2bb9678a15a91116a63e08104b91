<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nn">
    <dependencies>
        <dependency catalog="qtbase_nn"/>
        <dependency catalog="qtmultimedia_nn"/>
    </dependencies>
</TS>
